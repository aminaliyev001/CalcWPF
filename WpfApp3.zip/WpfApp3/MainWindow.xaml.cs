﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private double cvalue = 0;
        private double values = 0;
        private string operation_ = string.Empty;
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button)
            {
                string content = button.Content.ToString();

                if (double.TryParse(content, out double number))
                {
                    cvalue = cvalue * 10 + number;
                    UpdateDisplay(cvalue);
                }
                else
                {
                    switch (content)
                    {
                        case "+":
                        case "-":
                        case "X":
                        case "/":
                            values = cvalue;
                            operation_ = content;
                            cvalue = 0;
                            break;

                        case "=":
                            Calculate();
                            break;

                        case "C":
                            cvalue = 0;
                            values = 0;
                            operation_ = string.Empty;
                            UpdateDisplay(cvalue);
                            break;

                        case "CE":
                            cvalue = 0;
                            UpdateDisplay(cvalue);
                            break;

                        case "1/x":
                            cvalue = 1 / cvalue;
                            UpdateDisplay(cvalue);
                            break;

                        case "x^2":
                            cvalue *= cvalue;
                            UpdateDisplay(cvalue);
                            break;

                        case "%":
                            cvalue = values * cvalue / 100;
                            UpdateDisplay(cvalue);
                            break;

                        case "+/-":
                            cvalue = -cvalue;
                            UpdateDisplay(cvalue);
                            break;
                    }
                }
            }
        }

        private void Calculate()
        {
            switch (operation_)
            {
                case "+":
                    cvalue = values + cvalue;
                    break;
                case "-":
                    cvalue = values - cvalue;
                    break;
                case "X":
                    cvalue = values * cvalue;
                    break;
                case "/":
                    if (cvalue != 0)
                        cvalue = values / cvalue;
                    else
                        MessageBox.Show("0-a bolune bilmez!");
                    break;
            }
            UpdateDisplay(cvalue);
        }

        private void UpdateDisplay(double value)
        {
            DisplayLabel.Content = value.ToString();
        }
    }
}
